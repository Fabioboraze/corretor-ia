import OpenAI from 'openai';

export async function POST(req) {
  try {
    const { imovel, tipoSaida } = await req.json();
    if (!process.env.OPENAI_API_KEY) {
      return Response.json({ error: 'Defina OPENAI_API_KEY no arquivo .env.local para ativar a geração.' }, { status: 400 });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const prompt = `Você é o CORRETOR IA, especialista em marketing e vendas imobiliárias no Brasil.

OBJETIVO: transformar dados de um imóvel em conteúdo comercial útil, elegante e específico, sem clichês vazios.

MODO: ${imovel.modo}
TIPO DE SAÍDA: ${tipoSaida}

DADOS DO IMÓVEL:
Nome: ${imovel.nome}
Tipo: ${imovel.tipo}
Bairro: ${imovel.bairro}
Cidade: ${imovel.cidade}
Preço: ${imovel.preco}
Área: ${imovel.area}
Quartos: ${imovel.quartos}
Suítes: ${imovel.suites}
Vagas: ${imovel.vagas}
Público: ${imovel.publico}
Diferenciais: ${imovel.diferenciais}

REGRAS:
- Não invente características não informadas.
- Se faltar informação, trabalhe apenas com o que existe.
- Em alto padrão, use linguagem de patrimônio, experiência, exclusividade, localização e valor percebido; evite “imóvel dos sonhos”.
- Seja comercial sem prometer valorização garantida.
- Escreva em português do Brasil.

Se tipoSaida = campanha, entregue: posicionamento, público, 5 headlines, roteiro de Reels 60s, legenda, anúncio Meta, mensagem WhatsApp, sequência de 3 follow-ups, 5 objeções com respostas e CTA final.
Se for outro tipo, entregue apenas a peça solicitada, com alta qualidade e pronta para uso.`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.6-luna',
      input: prompt
    });

    return Response.json({ resultado: response.output_text });
  } catch (error) {
    return Response.json({ error: error?.message || 'Erro interno.' }, { status: 500 });
  }
}
